<?php


$connection = mysqli_connect('localhost','root','','ecom');


session_start();