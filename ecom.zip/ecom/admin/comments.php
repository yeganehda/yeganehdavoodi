<div class="card mb-3">
    <div class="card-header">
        نظرات تایید نشده
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table float-right" style="direction: rtl">
                <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>ایمیل</th>
                    <th>محتوا</th>
                    <th>پذیرفتن</th>
                    <th>حذف</th>

                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>تست</td>
                    <td>تست</td>
                    <td>سلام نظر جدید</td>
                    <td><a href="#" class="btn btn-primary">پذیرفتن</a></td>
                    <td>
                        <a href="#" class="btn btn-danger">حذف</a>
                    </td>

                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<br>
<br>
<br>
<div class="card mb-3">
    <div class="card-header">
        نظرات تایید شده
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table float-right" style="direction: rtl">
                <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>ایمیل</th>
                    <th>محتوا</th>
                    <th>نپذیرفتن</th>
                    <th>حذف</th>

                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>تست</td>
                    <td>تست</td>
                    <td>سلام نظر جدید</td>
                    <td><a href="#" class="btn btn-primary">نپذیرفتن</a></td>
                    <td>
                        <a href="#" class="btn btn-danger">حذف</a>
                    </td>

                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

