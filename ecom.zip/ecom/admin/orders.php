<div class="card mb-3">
    <div class="card-header">
       سفارشات
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table float-right" style="direction: rtl">
                <thead>
                <tr>
                    <th>ردیف</th>
                    <th>تصویر</th>
                    <th>نام</th>
                    <th>دسته بندی</th>
                    <th>قیمت</th>
                    <th>مشاهده</th>
                    <th>حذف</th>

                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td><img src="../uploads/1.jpg" width="100px" height="70px"></td>
                    <td>تست</td>
                    <td>تست</td>
                    <td>100</td>
                    <td><a href="#" class="btn btn-primary">مشاهده</a></td>
                    <td>
                        <a href="#" class="btn btn-danger">حذف</a>
                    </td>

                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
